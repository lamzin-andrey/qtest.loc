-- phpMyAdmin SQL Dump
-- version 4.5.4
-- http://www.phpmyadmin.net
--
-- Хост: localhost
-- Время создания: Ноя 24 2019 г., 16:01
-- Версия сервера: 10.1.13-MariaDB
-- Версия PHP: 7.0.8

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- База данных: `qtest`
--

-- --------------------------------------------------------

--
-- Структура таблицы `comments`
--

CREATE TABLE `comments` (
  `id` int(11) NOT NULL COMMENT 'Первичный ключ.',
  `part` varchar(128) DEFAULT NULL COMMENT 'Часть url определяющая тип, например quick_start/branching',
  `uid` int(11) DEFAULT NULL COMMENT 'Номер автора',
  `parent_id` int(11) DEFAULT '0' COMMENT 'Номер родительского комментария',
  `title` varchar(128) DEFAULT NULL COMMENT 'Заголовок',
  `body` text COMMENT 'Текст комментария',
  `date_modify` datetime DEFAULT NULL COMMENT 'Время изменения',
  `is_deleted` int(11) DEFAULT '0' COMMENT 'Удален или нет.',
  `date_create` datetime DEFAULT NULL COMMENT 'время создания',
  `is_accept` int(11) DEFAULT '0' COMMENT 'Комментарий прошел модерацию'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Структура таблицы `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL COMMENT 'Первичный ключ.',
  `pwd` varchar(32) DEFAULT NULL COMMENT 'пароль',
  `email` varchar(64) DEFAULT NULL COMMENT 'email',
  `guest_id` varchar(32) DEFAULT NULL COMMENT 'md5( ip datetime) анонимного пользователя загрузившего файл',
  `last_access_time` datetime DEFAULT NULL COMMENT 'время последнего обращения к файлу',
  `is_deleted` int(11) DEFAULT '0' COMMENT 'Удален или нет. Может называться по другому, но тогда в cdbfrselectmodel надо указать, как именно',
  `date_create` datetime DEFAULT NULL COMMENT 'время создания',
  `delta` int(11) DEFAULT NULL COMMENT 'Позиция.  Может называться по другому, но тогда в cdbfrselectmodel надо указать, как именно',
  `name` varchar(64) DEFAULT NULL COMMENT 'Имя пользователя',
  `surname` varchar(64) DEFAULT NULL COMMENT 'Фамилия пользователя',
  `role` int(11) DEFAULT '0' COMMENT 'Роль пользователя 0 - пользователь 1 - модератор - 2 - админ',
  `current_task` varchar(7) DEFAULT NULL COMMENT 'Выбранная в данный момент задача формат: Вариант:Задание',
  `recovery_hash` varchar(32) DEFAULT NULL COMMENT 'Хэш md5 для восстановления пароля',
  `recovery_hash_created` datetime DEFAULT NULL COMMENT 'Время которое хеш действителен'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Дамп данных таблицы `users`
--

INSERT INTO `users` (`id`, `pwd`, `email`, `guest_id`, `last_access_time`, `is_deleted`, `date_create`, `delta`, `name`, `surname`, `role`, `current_task`, `recovery_hash`, `recovery_hash_created`) VALUES
(1, NULL, NULL, 'd3fad46b24979d15fe635083cd324852', NULL, 0, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL),
(3, '07b68be905ddc7243d684007163d9fcd', 'lamzin80@mail.ru', '493a5bfc47402a69b431c450df7651a9', NULL, 0, NULL, NULL, 'andrey', 'alamzin', 0, NULL, NULL, NULL);

-- --------------------------------------------------------

--
-- Структура таблицы `u_tests`
--

CREATE TABLE `u_tests` (
  `id` int(11) NOT NULL COMMENT 'Первичный ключ.',
  `uid` int(11) DEFAULT NULL COMMENT 'Номер пользователя, загрузившего файл',
  `t_type` int(11) DEFAULT NULL COMMENT 'Тип теста - 0 - варианты ответа, 1 - ответ на вопрос текстовый',
  `display_name` varchar(128) DEFAULT NULL COMMENT 'Имя теста для отображения',
  `short_desc` text COMMENT 'Краткое описание теста',
  `description` text COMMENT 'Полное описание теста',
  `info` text COMMENT 'Полезная информация о тесте, показывается на каждой странице, например информация о том, что все кавычки в ответах должны быть двойными',
  `t_name` varchar(32) DEFAULT NULL COMMENT 'Техническое имя теста',
  `is_deleted` int(11) DEFAULT '0' COMMENT 'Удален или нет.',
  `is_accepted` int(11) DEFAULT '0' COMMENT 'Модерирован или нет.',
  `is_published` int(11) DEFAULT '0' COMMENT 'Опубликован или нет.',
  `date_create` datetime DEFAULT NULL COMMENT 'время создания',
  `delta` int(11) DEFAULT NULL COMMENT 'Позиция. ',
  `folder` varchar(7) DEFAULT NULL COMMENT 'Каталог файлов от files',
  `reading_uri` varchar(255) DEFAULT NULL COMMENT 'Часть url которая транслитируется из display_name',
  `options` text COMMENT 'JSON Прочие опции теста, не вошедшие в структуру таблицы'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Дамп данных таблицы `u_tests`
--

INSERT INTO `u_tests` (`id`, `uid`, `t_type`, `display_name`, `short_desc`, `description`, `info`, `t_name`, `is_deleted`, `is_accepted`, `is_published`, `date_create`, `delta`, `folder`, `reading_uri`, `options`) VALUES
(1, 3, 1, 'Тест по Symfony 2', 'Тест по симфони 2, родился по мере чтения сайта symfony-gu.ru.\r\n\r\nВ ответах на вопросы используйте всегда двойные кавычки. Ответы на некоторые вопросы могут показаться вам неудачными, или даже неверными - вы можете предложить свои варианты ответов к тесту на странице комментариев к тесту.', 'Тест по симфони 2, родился по мере чтения сайта symfony-gu.ru', 'В ответах на вопросы используйте всегда двойные кавычки. Ответы на некоторые вопросы могут показаться вам неудачными, или даже неверными - вы можете предложить свои варианты ответов к тесту на странице комментариев к тесту.', 'symfony_2', 0, 1, 1, '2015-05-21 00:00:00', 1, '2015/05', 'test_po_symfony_2', NULL),
(2, 3, 1, 'Тест по Symfony 2 - use base', 'Тест по симфони 2, родился по мере чтения сайта symfony-gu.ru.\r\n\r\nВ ответах на вопросы используйте всегда двойные кавычки. Ответы на некоторые вопросы могут показаться вам неудачными, или даже неверными - вы можете предложить свои варианты ответов к тесту на странице комментариев к тесту.\r\nЭто тупо проверка загрузки вопросов с базы', 'Тест по симфони 2, родился по мере чтения сайта symfony-gu.ru', 'В ответах на вопросы используйте всегда двойные кавычки. Ответы на некоторые вопросы могут показаться вам неудачными, или даже неверными - вы можете предложить свои варианты ответов к тесту на странице комментариев к тесту.', 'ex_base', 0, 1, 1, '2015-05-21 00:00:00', 3, '2015/05', 'ex_base_url', '{"t_compare":"1","time_decision":"60","time_show_error_message":"7","time_show_success_message":"1","time_show_game_over_message":"7","time_show_win_screen":"5","test_score":"5","test_lives":"2","is_skip":"1","test_skip_score":"1","test_skip_border":"15","one_answer_success_message":"\\u041f\\u0440\\u0430\\u0432\\u0438\\u043b\\u044c\\u043d\\u043e!","one_answer_fail_message":"\\u041e\\u0448\\u0438\\u0431\\u043a\\u0430!","gameover_message":"GAME OVER"}'),
(8, 3, 1, 'Реальный тест про фейсбук АПИ', 'Тест по реализации https://www.youtube.com/watch?v=C55Ofl0lsBs', 'Учи ФАПИ', 'Не будет', 'realnii_test_pro_feisbuk_api', 0, 0, 0, '2015-06-08 15:05:36', 6, '2015/06', 'realnii_test_pro_feisbuk_api', '{"t_compare":"1","time_decision":"60","time_show_error_message":"5","time_show_success_message":"1","time_show_game_over_message":"5","time_show_win_screen":"15","test_score":"5","test_lives":"2","is_skip":"1","test_skip_score":"1","test_skip_border":"15","show_answer":"1","one_answer_success_message":"\\u041f\\u0440\\u0430\\u0432\\u0438\\u043b\\u044c\\u043d\\u043e!","one_answer_fail_message":"\\u041e\\u0448\\u0438\\u0431\\u043a\\u0430!","gameover_message":"GAME OVER"}'),
(9, 3, 1, 'Тест по паттернам проектирования', 'По книге &quot;банды четырех&quot;.\r\nСодержит вопросы, перечисляющие классы, реализующие паттерн, методы и поля классов.\r\n', 'По книге &amp;quot;банды четырех&amp;quot;.\r\nСодержит вопросы, перечисляющие классы,реализующие паттерн, методы и поля классов.', 'Правильные ответы на вопросы  стараются соответствовать диаграммам паттернов из книги &quot;Приемы объектно-ориентированного проектирования. Паттерны проектирования&quot;. Но при этом в методах указываются только типы аргументов (Например, на диаграмме классов паттерна Наблюдатель без использования ChangeManager сигнатура метода attach выглядит как Attach(Observer), а с использованием ChangeManager уже как Attach(Observer o). В ответах используйте без аргумента, то есть Attach(Observer). )', 'test_po_patternam_proektirovaniy', 0, 0, 0, '2015-06-18 15:31:19', 7, '2015/06', 'test_po_patternam_proektirovaniya', '{"t_compare":"1","time_decision":"60","time_show_error_message":"7","time_show_success_message":"1","time_show_game_over_message":"7","time_show_win_screen":"15","test_score":"10","test_lives":"2","is_skip":"1","test_skip_score":"1","test_skip_border":"15","show_answer":"1","one_answer_success_message":"\\u041f\\u0440\\u0430\\u0432\\u0438\\u043b\\u044c\\u043d\\u043e!","one_answer_fail_message":"\\u041e\\u0448\\u0438\\u0431\\u043a\\u0430!","gameover_message":"GAME OVER"}'),
(10, 3, 1, 'Тест по Symfony 3', 'Основан на тесте по Symfony 2.6, но часть вопросов актуализирована в соответствии с Symfony 3.4 созданым из Symfony-Cli 4.', 'Основан на тесте по Symfony 2.6, но часть вопросов актуализирована в соответствии с Symfony 3.4 созданым из Symfony-Cli 4.', 'Не щёлкай клювом!', 'hello_8', 0, 1, 1, '2019-11-08 13:37:49', 8, '2019/11', 'hello_8', '{"t_compare":"1","time_decision":"60","time_show_error_message":"10","time_show_success_message":"2","time_show_game_over_message":"10","time_show_win_screen":"15","test_score":"10","test_lives":"2","is_skip":"1","test_skip_score":"1","test_skip_border":"0","show_answer":"1","one_answer_success_message":"u041fu0440u0430u0432u0438u043bu044cu043du043e!","one_answer_fail_message":"u041eu0448u0438u0431u043au0430!","gameover_message":"GAME OVER"}'),
(11, 3, 1, 'Тест по работе с формами Symfony 3', 'Использование конструктора форм, перегрузка форм из сторонних бандлов.', 'Использование конструктора форм, перегрузка форм из сторонних бандлов.', '', 'test_po_rabote_s_formami_symfony', 0, 1, 1, '2019-11-16 11:16:36', 9, '2019/11', 'test_po_rabote_s_formami_symfony_3', '{"t_compare":"1","time_decision":"60","time_show_error_message":"2","time_show_success_message":"3","time_show_game_over_message":"5","time_show_win_screen":"10","test_score":"10","test_lives":"2","is_skip":"1","test_skip_score":"1","test_skip_border":"0","show_answer":"1","one_answer_success_message":"u041fu0440u0430u0432u0438u043bu044cu043du043e!","one_answer_fail_message":"u041eu0448u0438u0431u043au0430!","gameover_message":"GAME OVER"}');

-- --------------------------------------------------------

--
-- Структура таблицы `u_tests_content`
--

CREATE TABLE `u_tests_content` (
  `id` int(11) NOT NULL COMMENT 'Первичный ключ.',
  `u_tests_id` int(11) DEFAULT NULL COMMENT 'Номер теста',
  `question` text COMMENT 'Текст вопроса',
  `answer` text COMMENT 'Ответ на вопрос, в json формате если u_tests.t_type == 0',
  `r_answer` int(11) DEFAULT NULL COMMENT 'Номер правильного варианта ответа на вопрос если u_tests.t_type == 0',
  `is_deleted` int(11) DEFAULT '0' COMMENT 'Удален или нет.',
  `date_create` datetime DEFAULT NULL COMMENT 'время создания',
  `delta` int(11) DEFAULT NULL COMMENT 'Позиция. '
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Дамп данных таблицы `u_tests_content`
--

INSERT INTO `u_tests_content` (`id`, `u_tests_id`, `question`, `answer`, `r_answer`, `is_deleted`, `date_create`, `delta`) VALUES
(1, 2, 'Вы находитесь в консоли linux, текущая директория - корневая директория проекта симфони 2.6.6. Введите команду для генерации бандла HelloBundle', 'php app/console generate:bundle --namespace=Acme/HelloBundle', NULL, 0, '2019-11-08 13:51:16', 2),
(2, 2, 'Что такое Acme?', 'Имя компании по умолчанию', NULL, 0, '2019-11-08 13:51:19', 9),
(15, 8, 'Введите адрес страницы на Facebook, которая позволяет авторизовыватсья в веб приложениях. Ответ дайте от корня сайта facebook, например если вы считаете, что это https://facebook.com/api/auth/catch?param1=... введите /api/auth/catch', '/dialog/oauth', NULL, 0, '2015-06-08 16:28:15', 15),
(17, 5, 'Q6', 'A6', NULL, 0, '2015-06-08 15:37:30', 13),
(19, 2, 'Укажите путь к YML файлу конфигурации соединения с базой данных по умолчанию (от корня проекта symfony 2.6.6, например app/config/... или src/Acme/YourBundle/Resources/config/...)', 'app.config/parameters.yml', NULL, 0, '2015-06-08 16:06:23', 22),
(20, 2, 'Вы находитесь в консоли linux, текущая директория - корневая директория проекта симфони 2.6.6 Введите команду для создания базы данных', 'php app/console doctrine:database:create', NULL, 0, '2015-06-08 16:08:12', 14),
(21, 2, 'Вы находитесь в консоли linux, текущая директория - корневая директория проекта симфони 2.6.6 Введите команду для создания класса модели c именем Product в пакете AcmeHelloBundle содержащей три поля: имя, описание и цена. Типы полей: строка в 255 символов, текст, дробное число.', 'php app/console doctrine:generate:entity --entity="AcmeHelloBundle:Product" --fields="name:string(255) description:text price:float"', NULL, 0, '2019-11-08 13:51:20', 11),
(22, 8, 'Перечислите имена трех GET параметров, котрые вам необходимо передать по адресу https://facebook.com/dialog/oauth', 'client_id, response_type, redirect_uri', NULL, 0, '2015-06-08 16:30:20', 16),
(23, 8, 'Введите имя секции в файле composer и строку подключающую facebook php sdk четвертой версии. Вместо точной версии используйте 4.x.x.', '&quot;facebook/php-sdk-v4&quot; : &quot;4.x.x&quot;', NULL, 0, '2015-06-14 16:57:46', 18),
(24, 8, 'Для установки facebook sdk использовать composer install или composer update? (Ответ одним словом)', 'update', NULL, 0, '2015-06-08 16:41:36', 20),
(25, 8, 'Напишите две инструкции use для подключения модулей Facebook sdk необходимых для получения списка друзей TestUsers.', 'use Facebook\\FacebookRequest;\nuse Facebook\\FacebookSession;', NULL, 0, '2015-06-09 11:42:23', 19),
(26, 8, 'Вам доступны идентификатор приложения $app_id  и его &quot;секрет&quot; $app_secret. Введите строку php кода, указывающую FacebookSDK использовать это определенное приложение.', 'FacebookSession::setDefaultApplication($app_id, $app_secret);', NULL, 0, '2015-06-09 14:26:19', 21),
(27, 8, 'Как открыть сессию Facebook в приложении, если у вас есть $access_token авторизованного пользователя? ($session = )', '$session = new FacebookSession($access_token);', NULL, 0, '2015-06-09 12:33:42', 25),
(28, 8, 'Введите url позволяющий получить access_token приложения. Без get параметров.', 'https://graph.facebook.com/oauth/access_token', NULL, 0, '2015-06-08 16:53:08', 22),
(29, 8, 'Перечислите get параметры url, позволяющие получить access_token приложения.', 'client_id, client_secret, grant_type, redirect_uri', NULL, 0, '2015-06-08 16:55:41', 23),
(30, 8, 'Введите значение параметра response_type', 'token', NULL, 0, '2015-06-09 11:54:18', 17),
(31, 8, 'Введите значение параметра grant_type', 'client_credentials', NULL, 0, '2015-06-09 11:56:41', 24),
(32, 8, 'Вам доступен $app_access_token приложения, $access_token авторизованного пользователя facebook, $app_id приложения и $app_secret.\nВведите значение третьего аргумента конструктора FacebookRequest для получения списка TestUsers. Ответ - строка php кода. (&quot;*&quot; . *** . &quot;...&quot; . **;)', '&quot;/&quot; . $app_id . &quot;/accounts/test-users?&quot; . $app_access_token;', NULL, 0, '2015-06-14 16:57:18', 26),
(33, 8, 'Вам доступны переменные $fb_session = new FacebookSession($access_token);\n$path = &quot;/&quot; . $app_id . &quot;/accounts/test-users?&quot; . $app_access_token;\nВведите строку php кода, создающую экземпляр класса FacebookRequest; ($request = ...;)', '$request = new FacebookRequest($fb_session, &amp;quot;GET&amp;quot;, $path);', NULL, 0, '2015-06-09 12:47:40', 27),
(34, 8, 'Вам доступна переменная $request = new FacebookRequest($fb_session, &quot;GET&quot;, $path);\nВведите строку php кода, возвращающую в переменную $data данные результата запроса как массив. ($data = ...&amp;quot;)', '$data = $request-&gt;execute()-&gt;getGraphObject()-&gt;asArray();', NULL, 0, '2015-06-09 12:50:55', 28),
(35, 8, 'Вы выполнили запрос с целью получить список id TestUsers приложения. \n$data = $request-&gt;execute()-&gt;getGraphObject()-&gt;asArray(); Введите наименование ключа массива $data  и его тип, содержащий массив TestUsers (key, type);', 'data, array', NULL, 0, '2015-06-09 12:54:21', 29),
(36, 8, '$test_user = $data[&amp;quot;data&amp;quot;][0];\n\nКак получить access_token тестового пользователя, при условии, что он задан. ($test_user_access_token = $test_user....;)', '$test_user_access_token = $test_user-&gt;access_token;', NULL, 0, '2015-06-09 12:57:33', 30),
(37, 8, '$data = $request-&gt;execute()-&gt;getGraphObject()-&gt;asArray();\n$test_user = $data[&amp;quot;data&amp;quot;][0];\nМожно ли ожидать, что $test_user гарантированно содержит поле access_token?', 'Нет', NULL, 0, '2015-06-09 12:59:49', 31),
(38, 8, '$test_user_access_token = $test_user-&gt;access_token;\n\nВведите значение параметра аргумента $path для конструктора FacebookRequest ($path = &amp;quot;*&amp;quot; . * . **;)', '$path = &amp;quot;/&amp;quot; . $test_user-&gt;id . &amp;quot;/?access_token=&amp;quot; . $test_user_access_token;', NULL, 0, '2015-06-09 13:04:05', 32),
(39, 9, 'Перечислите классы, реализующие паттерн Стратегия.', 'Context, Strategy, ConcreteStrategyN', NULL, 0, '2015-06-18 15:37:45', 33),
(40, 9, 'Паттерн Стратегия. Перечислите методы класса Context. Использование круглых скобок - обязательно.', 'ContextInterface()', NULL, 0, '2015-06-18 15:35:10', 34),
(41, 9, 'Паттерн Стратегия. Перечислите методы класса Strategy. Использование круглых скобок - обязательно.', 'AlgorithmInterface()', NULL, 0, '2015-06-18 15:36:38', 35),
(42, 9, 'В книге &quot;Банды четырех&quot; в описании известных применений паттерна Стратегия есть один пример, очень актуальный для веб-разработки. Введите имя класса, который обычно реализует в веб-движках описываемую в разделе задачу.', 'Validator', NULL, 0, '2015-06-19 12:23:51', 36),
(43, 9, 'Перечислите классы, реализующие паттерн Наблюдатель без использования ChangeManager.', 'Subject, Observer, ConcreteSubject, ConcreteObserver', NULL, 0, '2015-06-19 11:52:39', 37),
(44, 9, 'Паттерн Observer. Перечислите методы класса Subject. Использование круглых скобок - обязательно.', 'attach(Observer), detach(Observer), notify()', NULL, 0, '2015-06-19 12:54:13', 38),
(45, 9, 'Паттерн Observer. Перечислите поля и методы класса ConcreteSubject. Использование круглых скобок для методов - обязательно.', 'getState(), setState(), subjectState', NULL, 0, '2015-06-19 11:57:47', 39),
(46, 9, 'Паттерн Observer. Пусть класс Subject содержит массив _observers \n и длину этого массива в поле _count\nдобавленных с помощью attach() наблюдателей. Наберите необходимую часть кода метода notify(); (На диаграмме этого кода нет, но есть соответствующая выноска)', 'for (int i = 0; i &lt; _count; i++) {\n    _observers[i]-&gt;update();\n}', NULL, 0, '2015-06-19 12:56:28', 40),
(47, 9, 'Паттерн Observer.\nМожет ли конструктор класса Observer принимать аргументом ConcreteSubject?(Да / Нет / Обязан)', 'Обязан', NULL, 0, '2015-06-19 12:10:26', 41),
(48, 9, 'Паттерн Observer.\nКаким образом экхемпляр класса ConcreteObserver получает данные о состоянии субъекта при вызове метода Update? (Через аргументы update / строка кода)', 'subject-&gt;getState();', NULL, 0, '2015-06-19 12:14:36', 42),
(49, 9, 'Паттерн Наблюдатель. Перечислите методы класса Observer. Использование круглых скобок - обязательно.', 'update()', NULL, 1, '2015-06-19 12:16:44', 43),
(50, 9, 'Паттерн Наблюдатель. Перечислите методы класса Observer. Использование круглых скобок - обязательно.', 'update()', NULL, 0, '2015-06-19 12:17:55', 44),
(51, 9, 'Перечислите классы, реализующие паттерн Наблюдатель с использованием ChangeManager (имеется ввиду диаграмма классов из книги).', 'Subject, Observer, ChangeManager, SimpleChangeManager, DAGChangeManager', NULL, 0, '2015-06-19 12:26:54', 45),
(52, 9, 'Паттерн Observer. Перечислите поля и методы класса ChangeManager. Использование круглых скобок для методов - обязательно.', 'Register(Subject, Observer), Unregister()\nUnregister(Subject, Observer)\nNotify(), Subject - Observer mapping', NULL, 0, '2015-06-19 12:32:24', 46),
(53, 9, 'Паттерн Observer. С использованием ChangeManager. Диаграмма. Выноска из какого-то метода выглядит так: chman-&gt;register(this, o);\nВведите имя класса и имя метода.(ClassName::methodName([argument1Type, argument2Type, ...]);)', 'Subject::Attach(Observer);', NULL, 0, '2015-06-19 12:44:18', 47),
(54, 9, 'Паттерн Observer. С использованием ChangeManager. Диаграмма. Выноска из какого-то метода выглядит так: chman-&gt;notify();\nВведите имя класса и имя метода.(ClassName::methodName([argument1Type, argument2Type, ...]);)', 'Subject::Notify();', NULL, 0, '2015-06-19 12:45:15', 48),
(55, 9, 'Паттерн Observer. С использованием ChangeManager. Диаграмма. Процитируйте выноску из метода SimpleChangeManager::notify();', 'Для всех субъектов s\n Для всех наблюдателей o в s\n   o-&gt;Update(s)', NULL, 0, '2015-06-19 12:47:24', 49),
(56, 9, 'Паттерн Observer. С использованием ChangeManager. Диаграмма. Процитируйте выноску из метода DAGChangeManager::notify();', 'Пометить всех наблюдателей для обновления\nОбновить всех помеченных наблюдателей', NULL, 0, '2015-06-19 12:48:25', 50),
(57, 10, 'Укажите имя файла с параметрами соединения с базой данных', '.env', NULL, 0, '2019-11-08 14:00:08', 51),
(58, 10, 'Укажите имя файла, который считывает параметры соединения с базой данных из файла .env', 'config/packages/doctrine.yaml', NULL, 0, '2019-11-08 14:01:51', 52),
(59, 10, 'Вы находитесь в консоли linux, текущая директория - корневая директория проекта симфони 3.4 Введите команду для создания базы данных.', 'php bin/console doctrine:database:create', NULL, 0, '2019-11-08 14:02:50', 53),
(60, 10, 'Вы находитесь в консоли linux, текущая директория - корневая директория проекта симфони 3.4 Введите команду для создания класса сущности.', 'php bin/console make:entity', NULL, 0, '2019-11-20 13:31:27', 54),
(61, 10, 'Создалась ли таблица базы данных в результате предыдущей команды?', 'Нет', NULL, 0, '2019-11-08 14:05:09', 55),
(62, 10, 'Вы находитесь в консоли linux, текущая директория - корневая директория проекта симфони 2.6.6 Введите команду для генерации таблицы базы данных на основе файлов конфигурации, создавшихся в результате предыдущих действий', 'php bin/console doctrine:schema:update --force', NULL, 0, '2019-11-08 14:05:38', 56),
(63, 10, 'Вы набираете код внутри метода контроллера, в котором вам доступен класс Product, созданный ранее в этом тесте. Вы хотите получить доступ к методам экземпляра класса EntityManager, присвоив его переменной $em. Введите соответствущую строку php кода.', '$em = $this->getDoctrine()->getManager();', NULL, 0, '2019-11-08 14:06:19', 57),
(64, 10, 'Вы набираете код внутри метода контроллера, в котором вам доступен класс Product, созданный ранее в этом тесте. Вы хотите передать объект $product класса Product экземпляру класса EntityManager (экземпляр у вас уже определен в переменной $em). Введите соответствущую строку php кода.', '$em->persist($product);', NULL, 0, '2019-11-08 14:06:50', 58),
(65, 10, 'Вы набираете код внутри метода контроллера, в котором вам доступен класс Product, созданный ранее в этом тесте. Вы хотите записать последние изменения в базу данных. Введите соответствущую строку php кода.', '$em->flush();', NULL, 0, '2019-11-08 14:07:14', 59),
(66, 10, 'Вы набираете код внутри метода контроллера src/Controller/DefaultController.php, в котором вам доступен класс сущности App\\Entity\\Product. Вы хотите получить в переменную $repository объект, который предоставит вам методы поиска продуктов по значениям идентификатора и других полей модели. Введите соответствущую строку php кода.', '$repository = $this->getDoctrine()->getRepository("App:Product");', NULL, 0, '2019-11-22 08:25:16', 60),
(67, 10, 'Вы набираете код внутри метода контроллера src/Controller/DefaultController.php. Вы хотите получить аргумент $request, который предоставит вам методы доступа к переменным POST, GET и сессии (и еще много всего). Введите соответствующую строку php кода.', 'Request $request', NULL, 0, '2019-11-18 08:41:18', 61),
(68, 10, 'Q1', 'A1', NULL, 1, '2019-11-08 14:23:15', 62),
(69, 10, 'Вы набираете код внутри метода контроллера src/Controller/DefaultController.php. У вас есть объект $request из предыдущего вопроса. Вам нужен в переменной $session объект, предоставляющий доступ к сессии пользователя. Введите соответствующую строку php кода.', '$session = $request->getSession();', NULL, 0, '2019-11-08 14:23:14', 63),
(70, 10, 'Вы хотите сделать в своем контроллере доступным объектSecurity. Напишите соответствующую инструкцию use (use Symfony ... Security...; ) подключающую необходимый компонент.', 'use Symfony\\Component\\Security\\Core\\Security;', NULL, 0, '2019-11-22 08:23:35', 64),
(71, 10, 'Вы набираете код внутри метода контроллера src/Controller/DefaultController.php, вам доступен Security и объект $request = $this->getRequest();. Напишите строку php кода, возвращающую true если произошла ошибка аутентификации', '$request->attributes->has(Security::AUTHENTICATION_ERROR)', NULL, 0, '2019-11-13 13:50:42', 65),
(72, 10, 'Вы набираете код внутри метода контроллера src/Controller/DefaultController.php, вам доступен Security и объект $session = $this->getRequest()->getSession();. Напишите строку php кода, возвращающую из сессии ошибку аутентификации в переменную $error', '$error = $session->get(Security::AUTHENTICATION_ERROR);', NULL, 0, '2019-11-13 13:50:41', 66),
(73, 10, 'Вы набираете код внутри метода контроллера src/Controller/DefaultController.php, вам доступен Security и объект $session = $this->getRequest()->getSession();. Напишите строку php кода, возвращающую из сессии последнее введенное  в форму логина имя пользователя,  $last_name = ...', '$last_name = $session->get(Security::LAST_USERNAME);', NULL, 0, '2019-11-13 13:50:55', 67),
(74, 10, 'Вы редактируете файл config/packages/security.yaml. Вы хотите задать конфигурацию безопасности для всего сайта. Какую секцию конфигурации будете редактировать и в какой секции она находится? Ответ дайте в форме section_name в parent_section_name.', 'main в firewalls', NULL, 0, '2019-11-24 14:50:37', 68),
(75, 10, 'Вы редактируете файл config/packages/security.yaml. Вы хотите задать конфигурацию безопасности так, чтобы брандмауер срабатывал при запросе любого url на вашем сайте. Введите соответствующую строку yml конфигурации.', 'pattern: ^/', NULL, 0, '2019-11-24 14:51:15', 69),
(76, 10, 'Вы редактируете файл config/packages/security.yaml. Брандмауер срабатывает при запросе любого url на вашем сайте, но вы хотите дать анонимным пользователям возможность просматривать его страницы. Введите соответствующую строку yml конфигурации.', 'anonymous: ~', NULL, 0, '2019-11-24 14:51:45', 70),
(77, 10, 'Вы редактируете файл app/config/security.yml. Что значит значение ключа конфигурации ~?. Например, что значит ~ в строке yml файла "anonymous: ~"', 'По умолчанию', NULL, 0, '2019-11-24 14:51:51', 71),
(78, 10, 'Вы редактируете файл config/packages/security.yaml. Добавьте в секцию main настройку, указывающую, что вы хотите использовать html форму логина (с путями по умолчанию)', 'form_login: ~', NULL, 0, '2019-11-24 14:52:14', 72),
(79, 10, 'Вы редактируете в файле app/config/security.yml секцию form_login. Перечислите через запятую два ключа, задающие пути, использующиеся при действии логина.', 'check_path, login_path', NULL, 0, '2019-11-08 14:27:39', 73),
(80, 10, 'Вы хотите использовать SwiftMailer для отправки письма в коде контроллера. Введите инструкцию use подключающую необходимый пакет', 'use Symfony\\Bundle\\SwiftmailerBundle;', NULL, 0, '2019-11-08 14:28:24', 140),
(81, 10, 'Как в контроллере получить объект для формирования email сообщения (используя swiftmailer)? ($message = ...;)', '$message = new Swift_Message();', NULL, 0, '2019-11-15 09:50:19', 141),
(82, 10, 'В строке $s у вас содержится html код сообщения. Введите вызов метода $message->setBody позволяющий отправить вам сообщение в формате html  и кодировке UTF-8', '$message->setBody($s, "text/html", "UTF-8");', NULL, 0, '2019-11-08 14:30:12', 143),
(83, 10, '$message = new \\Swift_Message(); Перечислите методы объекта message (без аргументов и круглых скобок), позволяющие задать тему письма, текст письма, адрес отправителя, адрес получателя.', 'setSubject, setBody, setFrom, setTo', NULL, 0, '2019-11-08 14:30:40', 142),
(84, 10, 'Введите строку php кода, позволяющий отправить вам сообщение $message из контроллера.', '$this->get("mailer")->send($message);', NULL, 0, '2019-11-08 14:30:56', 144),
(85, 10, 'Вы редактируете в файле config/packages/security.yml секцию form_login. Введите значение ключа login_path по умолчанию.', '/login', NULL, 0, '2019-11-08 14:32:29', 74),
(86, 10, 'Вы редактируете в файле config/packages/security.yml секцию form_login. Введите значение ключа check_path по умолчанию.', '/login_check', NULL, 0, '2019-11-08 14:32:57', 75),
(87, 10, 'Вы редактируете в файле config/packages/security.yaml секцию form_login. Вы задали свои оригинальные значения для путей к форме логина и скрипту проверки успешной аутентификации. Что необходимо ещё сделать в другом файле конфигурации, чтобы логически завершить это действие? Ответ дайте в форме "У**ть м**ы в файле config/..."', 'Указать маршруты в файле config/routes.yaml', NULL, 0, '2019-11-13 08:27:26', 76),
(88, 10, 'Вы работаете в "свежеустановленом" проекте симфони 3.4, вы не конфигурировали .htaccess  и все url в вашем проекте начинаются с /web/app_dev.php/ или /web/app.php/. Вы добавили аутентификацию пользователя через форму логина и хотите, чтобы при запросе url /web/app_dev.php/logout пользователь "разлогинился". Какую минимально необходимую строку надо добавить в секцию secured_area в файле config/packages/security.yaml?', 'logout: ~', NULL, 0, '2019-11-24 14:54:08', 78),
(89, 10, 'Для достижения цели, поставленной в предыдущем вопросе вам надо ещё создать некий маршрут в файле. Какое имя маршрута и в каком файле? Ответ дайте в форме route_name в файле config/....', 'logout в файле config/routes.yaml', NULL, 0, '2019-11-11 13:30:18', 79),
(90, 10, 'Logout заработал, но после разлогина вас перенаправляет на страницу /web/app_dev.php/, а вы хотите на /web/app_dev.php/hello/Anonymous. В каком файле, в какой секции и что надо ввести для этого?. Ответ наберите в виде config/.., section_name, key: value.', 'config/packages/security.yaml, logout, target: /hello/Anonymous', NULL, 0, '2019-11-11 13:30:17', 81),
(91, 10, 'Для достижения цели, поставленной в предыдущем вопросе вы создали маршрут logout в файле config/routes.yaml. В секции logout файла security.yaml должна быть минимум одна строка. Наберите её.', 'pattern: /logout', NULL, 1, '2019-11-22 08:42:38', 80),
(92, 10, 'Вы набираете код внутри контроллера. Как получить объект авторизованного пользователя используя token_storage? ($user = $this->...;)', '$user = $this->get("security.token_storage")->getToken()->getUser();', NULL, 0, '2019-11-22 08:37:59', 82),
(93, 10, 'Вы набираете код внутри контроллера. Вы получили объект авторизованного пользователя в переменную $user с помощью строки кода $user = $this->get("security.token_storage")->getToken()->getUser(); Какой тип переменной $user если пользователь НЕ авторизован?. Ответ дайте в виде имени типа данных php или Symfony, например TestUser, integer, string, bool, array.', 'string', NULL, 0, '2019-11-11 13:46:07', 83),
(94, 10, 'Вы набираете код внутри контроллера. Вы получили объект авторизованного пользователя в переменную $user с помощью строки кода $user = $this->get("security.token_storage")->getToken()->getUser(); Вы собираетесь получить объект шифровальщика в аргумент $encoder. Введите соответствующую строку php кода (Symfony... $encoder).', '\\Symfony\\Component\\Security\\CoreEncoder\\UserPasswordEncoderInterface $encoder', NULL, 0, '2019-11-24 08:30:32', 84),
(95, 10, 'Вы создали класс CUser, реализующий UserInterface, код этой реализации расположили в src/Entity/CUser.php. Теперь вы хотите указать, что пароль для данного типа пользователей следует шифровать алгоритмом bcrypt. Введите соответствующую строку yml конфигурации.', 'App\\Entity\\CUser: { algorithm: bcrypt }', NULL, 0, '2019-11-13 14:16:35', 86),
(96, 10, 'Вы создали класс CUser, реализующий UserInterface, код этой реализации расположили в src/Entity/CUser.php. Теперь вы хотите указать, что информацию о пользователях следует хранить в экземплярах именно этого класса. Как называется секция, существующая в файле config/packages/security.yaml в секции security, которую вы будете редактировать для достижения поставленной цели?', 'providers', NULL, 0, '2019-11-13 14:20:13', 88),
(97, 10, 'Для достижения цели, поставленной в предыдущем вопросе вы редактируете дочернюю секцию providers provider_name. Перечислите имена трех ключей, которые вам необходимо добавить.', 'entity, class, property', NULL, 0, '2019-11-11 14:07:32', 89),
(98, 10, 'Вы создали класс CUser, реализующий UserInterface, код этой реализации расположили в src/Entity/CUser.php. Теперь вы хотите указать, что информацию о пользователях следует хранить в экземплярах именно этого класса. Введите значение ключа class в этом случае.', 'App\\Entity\\CUser', NULL, 0, '2019-11-13 14:22:16', 90),
(99, 10, 'Чего не хватает в предыдущей конфигурации form_login? (Ответ одним словом, "Не хватает ...")', 'провайдера', NULL, 0, '2019-11-24 14:56:37', 94),
(100, 10, 'Вы создали класс CUser, реализующий UserInterface, код этой реализации расположили в src/Entity/CUser.php. С целью указать, что информацию о пользователях следует хранить в экземплярах именно этого класса вы добавили непосредственно в секцию providers строку entity: { class: AppEntityCUser, property:username }. Будет ли работать эта конфигурация?', 'Нет', NULL, 0, '2019-11-18 08:28:09', 93),
(101, 10, 'Как должна называться секция, в которой должны располагаться ключи  class и property (в контексте четырех последних вопросов)', 'entity', NULL, 0, '2019-11-13 14:24:55', 92),
(102, 10, 'Для достижения цели, поставленной в предыдущем вопросе вы должны добавить еще один ключ помимо ключа class, с определеннным значением. Введите эту конкретную строку в yml формате. (Ответ в формате ключ: значение)', 'property: username', NULL, 0, '2019-11-11 14:18:01', 91),
(103, 10, 'Вы сгенерировали пакет --namespace=Acme/HelloAnnotationBundle. Вы хотите указать для indexAction шаблон test.html.twig, который лежит в одном каталоге со сгенерированным по умолчанию шаблоном index.html.twig. Введите соответствующую аннотацию @Template', '@Template("AcmeHelloAnnotationBundle:Default:test.html.twig")', NULL, 0, '2019-11-13 14:25:13', 95),
(104, 10, 'Вы набираете код в методе контроллера, хотите вернуть данные array("name" => $name) в json формате. В документации symfony 3.4 для этого используются две строки php кода. Введите первую из них (кавычки в ответе используйте двойные). ($response = ...)', '$response = new Response( json_encode( ["name" => $name] ) );', NULL, 0, '2019-11-18 08:29:55', 96),
(105, 10, 'Вы набираете код в методе контроллера, хотите вернуть данные в json формате. В документации symfony 3.4 для этого используются две строки php кода. Введите вторую из них (кавычки в ответе используйте двойные). ($response->...)', '$response->headers->set("Content-Type", "application/json");', NULL, 0, '2019-11-11 14:17:56', 97),
(106, 10, 'Надо ли указывать маршруты для путей секции form_login, если их значения оставлены по умолчанию? (Да/Нет)', 'Да', NULL, 1, '2019-11-13 13:58:35', 99),
(107, 10, 'Вы работаете в "свежеустановленом" проекте симфони 2.6.6, вы не конфигурировали .htaccess  и все url в вашем проекте начинаются с /web/app_dev.php/ или /web/app.php/. Вы указали атрибут html формы action="{{ path("acme_user_add") }}" и хотите чтобы форма отправлялась по адресу /web/app_dev.php/user/add. Введите соответствующую аннотацию.', '@Route("/user/add", name="acme_user_add")', NULL, 0, '2019-11-13 14:32:23', 98),
(108, 10, 'Вы набираете код в определении сущности, хотите сделать обязательным для ввода поле password. Подключите модуль, позволяющий использовать Assert . (use ... AS Assert;)', 'use Symfony\\Component\\Validator\\Constraints AS Assert;', NULL, 0, '2019-11-13 08:37:19', 101),
(109, 10, 'Вы набираете код в определении сущности, хотите сделать обязательным для ввода поле password. Введите соответcтвующую строку аннотации. (@...)', '@Assert\\NotBlank()', NULL, 0, '2019-11-12 13:13:49', 102),
(110, 10, 'Измените ответ на предыдущий вопрос так, чтобы сообщение о пустом поле пароля сменилось на "Password required".', '@Assert\\NotBlank(message="Password required")', NULL, 0, '2019-11-12 13:14:53', 103),
(111, 10, 'Вы набираете код в определении сущности. Подключите модуль, позволяющий использовать UniqueEntity . (use Symfony\\...;)', 'use Symfony\\Bridge\\Doctrine\\Validator\\Constraints\\UniqueEntity;', NULL, 0, '2019-11-12 13:16:43', 104),
(112, 10, 'Вы набираете код в определении сущности. В сущности есть два поля (one, two), значения каждого из которых должны быть уникальными для каждой записи. Введите соответствующую аннотацию (аннотации) UniqueEntity . (@...[@...])', '@UniqueEntity("one") @UniqueEntity("two")', NULL, 0, '2019-11-12 13:16:42', 105),
(113, 10, 'Вы набираете код в определении сущности. В сущности есть два поля (one, two), значения которых должны быть уникальными для каждой записи (составной ключ). Введите соответствующую аннотацию (аннотации) UniqueEntity . (@...[@...])', '@UniqueEntity(fields={"one", "two"})', NULL, 0, '2019-11-12 13:18:14', 106),
(114, 10, 'Вы хотите сделать активацию вновь зарегистрированного пользователя по email. Вам необходимо создать класс, реализующий некий интерфейс. Введите название интерфейса.', 'UserProviderInterface', NULL, 0, '2019-11-12 13:19:33', 107),
(115, 10, 'Для достижения цели, поставленной в предыдущем вопросе, вы создали класс Acme/HelloBundle/Entity/CUserProvider.php. Введите название метода, в котором логично сделать проверку на то, активировал уже пользователь свой аккаунт или нет.', 'loadUserByUsername', NULL, 0, '2019-11-12 13:19:33', 108),
(116, 10, 'Вы хотите сделать активацию вновь зарегистрированного пользователя по email. Вам необходимо зарегистрировать класс Acme/HelloBundle/Entity/CUserProvider как сервис. Введите название xml файла, в котором логично это сделать. (dirname/...)', 'src/Acme/HelloBundle/Resources/config/services.xml', NULL, 0, '2019-11-12 13:19:32', 109),
(117, 10, 'Вы набираете код в методе контроллера, хотите сделать редирект по маршруту login. Введите соответcтвующую строку php кода. (return ...)', 'return $this->redirectToRoute("login")', NULL, 0, '2019-11-13 14:32:47', 100),
(118, 10, 'Вы хотите сделать активацию вновь зарегистрированного пользователя по email, для этого вы создали класс, реализующий UserProviderInterface  и зарегистрировали его как сервис с id="my_user_provider". Введите имя yml файла конфигурации, имя секции в этом файле, в которых вы укажете необходимость использовать ваш провайдер и yaml конфигурацию одной строкой. Формат ответа: имя файла (config/...), имя секции, provider: { ключ: значение }', 'config/packages/security.yaml, providers, provider: { id: my_user_provider }', NULL, 0, '2019-11-13 08:57:28', 111),
(119, 10, 'Для достижения цели, о которой шла речь в предыдущих пяти вопросах, класс сущности пользователя должен реализовывать два интерфейса. Перечислите их через запятую', 'UserInterface, EquatableInterface', NULL, 0, '2019-11-22 08:51:40', 112),
(120, 10, 'Где проще всего посмотреть пример реализации UserProviderInterface? Ответ - имя класса, входящего в symfony 3.4 "из коробки"', 'EntityUserProvider', NULL, 0, '2019-11-12 13:32:00', 113),
(121, 10, 'Вы набираете код в контроллере. Введите строку php кода, позволяющую получить параметр path маршрута my_personal_route. ($this->...;)', '$this->get("router")->getRouteCollection()->get("my_personal_route")->getPath();', NULL, 0, '2019-11-12 13:31:59', 114),
(122, 10, 'Вы с помощью doctrine создали класс сущности CUser в вашем приложении и одноименную таблицу в базе данных. Теперь вы хотите получить общее количество пользователей подтвердивших свой email, используя SQL запрос "SELECT COUNT(u.id) FROM CUser AS u WHERE u.email_verify = 1;" который вы планируете передать в метод EntityManager::createQuery(); Выполнится ли запрос? (Да/Нет)', 'Нет', NULL, 0, '2019-11-13 08:54:15', 115),
(123, 10, 'Что на что надо заменить в запросе "SELECT COUNT(u.id) FROM CUser AS u WHERE u.email_verify = 1;" для успешного использования метода EntityManager::createQuery();  (* на *)', 'CUser на App:CUser', NULL, 0, '2019-11-13 08:54:27', 116),
(124, 10, 'Какой метод логично использовать для получения результата запроса из последних двух вопросов? (methodName();)', 'getSingleResult();', NULL, 0, '2019-11-12 13:31:57', 117),
(125, 10, 'Укажите тип данных php или класс Symfony 3.4 который вернет метод getSingleResult()', 'array', NULL, 0, '2019-11-12 13:31:56', 118),
(126, 10, 'Вы выполнили код $res = $em->createQuery("SELECT COUNT(u.id) FROM AcmeHelloBundle:CUser AS u WHERE u.email_verify = 1;")->getSingleResult(); В каком элементе массива $res содержится запрошеное количество? (Ответ - число)', '1', NULL, 0, '2019-11-12 13:31:56', 119),
(127, 10, 'Вы определили в контроллере строковую переменную содержащую элементы html разметки. Значение передается в twig шаблон как messages. Как вывести в twig шаблоне значение messages без html тегов? (Ответ - {{ code }})', '{{ messages|raw }}', NULL, 0, '2019-11-12 13:31:54', 120),
(128, 10, 'Как вывести в twig шаблоне версию twig?', '{{ constant(&quot;Twig_Environment::VERSION&quot;) }}', NULL, 0, '2019-11-12 13:43:28', 121),
(129, 10, 'Вы хотите посмотреть все переменные доступные в twig шаблоне. Как называется подходящая twig функция?', 'dump', NULL, 0, '2019-11-12 13:43:29', 122),
(130, 10, 'Вы набираете код в контроллере. Как получить реальный url на сайте, ассоциированный с маршрутом my_route', '$this->generateUrl("my_route");', NULL, 0, '2019-11-12 13:43:30', 123),
(131, 10, 'Вы хотите определить класс формы для редактирования данных пользователя App:CUser, чтобы использовать формы симфони в вашем проекте. Введите значение namespace (namespace ...;).', 'namespace App\\Form\\Type;', NULL, 0, '2019-11-15 08:47:40', 124),
(132, 10, 'Вы хотите определить класс формы для редактирования данных пользователя App:CUser, чтобы использовать формы симфони в вашем проекте. Введите инструкции use подключающие необходимые компоненты в классе CUserType.', 'use Symfony\\Component\\Form\\AbstractType;\nuse Symfony\\Component\\Form\\FormBuilderInterface;', NULL, 0, '2019-11-13 09:02:06', 125),
(133, 10, 'Вы хотите определить класс формы CUserType для редактирования данных пользователя App:CUser, чтобы использовать формы симфони в вашем проекте. Перечислите названия двух необходимых к реализации методов в классе CUserType.', 'buildForm, getName', NULL, 0, '2019-11-13 09:02:14', 126),
(134, 10, 'Перечислите типы аргументов метода buildForm.', 'FormBuilderInterface, array', NULL, 0, '2019-11-12 13:43:33', 127),
(135, 10, 'Вы хотите, чтобы имя пользователя было не менее 2 символов и не более 15-ти. Введите сответствующую аннотацию.', '@Assert\\Length(min=2, max=15)', NULL, 0, '2019-11-12 13:43:34', 128),
(136, 10, 'Вы хотите запретить доступ пользователям на страницу /profile. Введите имя секции в security.yml и строку, которую надо туда добавить, если метод getRoles в вашем классе пользователя возвращает одну роль ROLE_USER. (Имя секции, строка)', 'access_control, -{ path: ^/profile, roles: ROLE_USER }', NULL, 0, '2019-11-12 13:43:35', 129),
(137, 10, 'Вы хотите использовать REST подход при проектировании вашего сайта и для этого редактирование записей выполняете в ответ на запросы использующие метод PATCH. При этом вы используете формы и соответственно класс, реализующий FormBuilderIneface. Какая инструкция необходима в теле метода buildForm(FormBuilderInterface $builder, array $options), чтобы в контроллере вызов $form->handleRequest() работал корректно? ($builder->...;)', '$builder->setMethod("PATCH");"', NULL, 0, '2019-11-12 13:43:37', 130),
(138, 10, 'Функциональные тесты. Напишите инструкцию use для подключения необходимого для их написания класса? (use ...;)', 'use Symfony\\Bundle\\FrameworkBundle\\Test\\WebTestCase;', NULL, 0, '2019-11-12 13:55:36', 131),
(139, 10, 'Функциональные тесты. Введите строку php кода, возвращающую в переменную $client объект, позволяющий выполнять действия имитирующие действия браузера. ($client = ...;)', '$client = static::createClient();', NULL, 0, '2019-11-12 13:55:34', 133),
(140, 10, 'Функциональные тесты. От какого класса должен наследоваться класс, реализующий тесты контроллера?', 'WebTestCase', NULL, 0, '2019-11-12 13:55:36', 132),
(141, 10, 'Функциональные тесты. Вы хотите, чтобы код $form = $client->request("GET", $routeName)-> selectButton($a)-> form($b, $c); $client->submit($form); отправил форму методом PATCH. Какая из переменных $a, $b, $c должна содержать строку "PATCH"? Ответ: $a, $b или $c.', '$c', NULL, 0, '2019-11-12 13:55:34', 134),
(142, 10, 'Переводы. В какой секции файла config.yml содержится default_locale?', 'framework', NULL, 0, '2019-11-12 13:55:31', 136),
(143, 10, 'Переводы. Укажите путь к yml файлу переводов сообщений для пакета AcmeHelloBundle от каталога src, локаль ru? (src/**.yml)', 'src/Acme/HelloBundle/Resources/translations/messages.ru.yml', NULL, 0, '2019-11-18 15:28:31', 137),
(144, 10, 'Вы хотите импортировать настройки из файла parameters.yml бандла AcmeBundle. Введите имя секции в файле config/parameters.yml и соответствующую строку. (имя секции, строка импорта)', 'imports, - { resource: @AcmeBundle/Resources/config/parameters.yml }', NULL, 0, '2019-11-13 09:06:35', 138),
(145, 10, 'В вашем файле parameters.yml задана конфигурация: box1: { subbox1_1: { key1: value32 } }. Как получить значение key1 в контроллере? ($this->...;)', '$this->container->getParameter(&quot;box1&quot;)[&quot;subbox1_1&quot;][&quot;key1&quot;];', NULL, 0, '2019-11-12 13:55:28', 139),
(146, 10, 'Связывание в Doctrine. На вашем сайте пользователи могут добавлять комментарии. Введите аннотацию "Один ко многим" для члена класса CUser comments, если автор комментария доступен в классе App\\Entity\\Comment через член user.', '@ORM\\OneToMany(targetEntity="App\\Entity\\Comment", mappedBy="user")', NULL, 0, '2019-11-15 09:25:36', 145),
(147, 10, 'Функциональные тесты. $crawler = $client->request($method, $routeName);. Страница содержит форму с инпутами типа текст, первый содержит значение. Как получить это значение в переменную $s? ($s = ...;)', '$s = $crawler->filter("input[type=text]")->first()->attr("value");', NULL, 0, '2019-11-12 13:55:33', 135),
(148, 10, 'Вы хотите наследоваться от шаблона src/Acme/HelloBundle/Resources/views/layout.html.twig. Введите сооответствующую строку twig шаблона. ({% ... %})', '{% extends &quot;AcmeHelloBundle::layout.html.twig&quot; %}', NULL, 0, '2019-11-12 13:58:51', 147),
(149, 10, 'Переводы. Укажите путь к yaml файлу переводов сообщений для приложения от каталога src, локаль ru? (*.yaml)', 'translations/messages.ru.yaml', NULL, 0, '2019-11-13 09:08:32', 146),
(150, 10, 'Надо перегрузить шаблон стороннего бандла FOSUserBundle. Какой каталог надо создать, чтобы поместить в него перегруженные шаблоны? (t.../)', 'templates/bundles/FOSUserBundle', NULL, 0, '2019-11-13 10:47:08', 148),
(151, 10, 'Вы хотите импортировать маршруты из стороннего бандла. Для этого вы создадите файл xxx.yml. В каком каталоге? (c.../)', 'config/routes', NULL, 0, '2019-11-13 10:51:31', 149),
(152, 10, 'Имеет ли значение конкретное имя yaml файла из предыдущего вопроса?', 'Нет', NULL, 0, '2019-11-13 10:56:07', 150),
(153, 10, 'Вы хотите перегрузить переводы на русский язык из стороннего бандла FOSUserBundle. Для этого вы создадите файл *.yml. Введите его имя? (t.../...yml)', 'translations/FOSUserBundle.ru.yml', NULL, 0, '2019-11-15 09:39:38', 151),
(154, 10, 'Надо ли указывать маршруты для путей секции form_login, если их значения оставлены по умолчанию? (Да/Нет)', 'Да', NULL, 0, '2019-11-13 13:56:58', 77),
(155, 10, 'Вы набираете код внутри контроллера. Вам доступен объект шифровальщика в аргументе $encoder; $user при этом имеет UserInterface. Вы собираетесь зашифровать пароль, хранящийся в переменной $password. Введите соответствующую строку php кода ($password = ...;).', '$password = $encoder->encodePassword($user, $password);', NULL, 0, '2019-11-13 14:15:00', 85),
(156, 10, 'В какой секции yml файла конфигурации должна располагаться строка - ответ на предыдущий вопрос?', 'encoders', NULL, 0, '2019-11-13 14:17:08', 87),
(157, 10, 'Вы хотите сделать активацию вновь зарегистрированного пользователя по email, для этого вы создали класс, реализующий UserProviderInterface  и зарегистрировали его как сервис в xml файле. Вы хотите, чтобы в конструктор вашего класса передавался экземпляр класса Doctrine. Введите соответствующую строку xml конфигурации. (&lt;argument...)', '&lt;argument type="service" id="doctrine" /&gt;', NULL, 0, '2019-11-15 14:02:01', 110),
(158, 11, 'Вы создаёте форму с помощью FormBuilderInterface.\nПеречислите типы трёх аргументов метода FormBuilderInterface::add.', 'string, string, array', NULL, 0, '2019-11-16 11:27:22', 152),
(159, 11, 'Что передаётся во втором аргументе ответа на предыдущий вопрос? Ответ на русском (Т... п..)', 'Тип поля', NULL, 0, '2019-11-16 11:27:21', 153),
(160, 11, 'Вы добавляете поле, одноимённого с которым нет в связанной с формой сущности. Какой ключ третьего аргумента метода add необходимо установить в fasle?', 'mapped', NULL, 0, '2019-11-16 11:27:36', 154),
(161, 11, 'Назовите ключ массива options который позволяет задать некоторые атрибуты тэга inpit.', 'attr', NULL, 0, '2019-11-16 11:29:32', 155),
(162, 11, 'Назовите тип ключа массива options который позволяет задать некоторые атрибуты тэга inpit.', 'array', NULL, 0, '2019-11-16 11:29:31', 156),
(163, 11, 'Вам нужно отобразить на форме несколько радиокнопок. Назовите короткое имя класса (без namespace), полное имя которого вы передадите в add вторым аргументом.', 'ChoiceType', NULL, 0, '2019-11-16 11:39:36', 157),
(164, 11, 'Приведите фрагмент двух опций из третьего аргумента метода add, которые гарантируют, что при использовании ChoiceType будет выведены именно радиокнопки и ни что другое. ("*" => *, "*" => *)', '"expanded" => true, "multiple" => false', NULL, 0, '2019-11-16 11:46:06', 158),
(165, 11, 'Вы заметили, что построенные с помощью FormBuilderInterface формы всегда выводят надпись слева от чекбокса. Что надо сделать, чтобы на всех подобных формах надпись стала показываться справа от чекбокса? (С.. т... о... .)', 'Создать тему оформления.', NULL, 0, '2019-11-16 11:46:05', 159),
(166, 11, 'В каком каталоге (относительно корня проекта Symfony 3.4) создадите twig файл? У вас приложение, а не бандл приложения.\n(t.../...)', 'templates/form', NULL, 0, '2019-11-16 11:46:04', 160),
(167, 11, 'Вы создали файл templates/form/layout.html.twig, в каком файле конфигурации надо указать, что этот файл надо использовать как тему оформления для форм по умолчанию? (c.../.../*.yaml)', 'config/packages/twig.yaml', NULL, 0, '2019-11-16 11:48:00', 161),
(168, 11, 'Вы редактируете config/packages/twig.yam с целью указать, что файл templates/form/layout.html.twig надо использовать как тему оформления для форм по умолчанию. Введите значение ключа конфигурации в секции twig.', 'form_themes', NULL, 0, '2019-11-16 12:01:16', 162),
(169, 11, 'Может ли значение из передыдущего вопроса находиться на одной строке с ключом form_themes?', 'Нет', NULL, 0, '2019-11-16 12:01:15', 164),
(170, 11, 'Вы заметили, что построенные с помощью FormBuilderInterface формы всегда выводят надпись слева от чекбокса. Вы хотите, чтобы на всех таких формах  надпись стала показываться справа от чекбокса. Вы создали файл темы оформления templates/form/layout.html.twig. Назовите имя блока, который в нём необходимо определить.', 'form_row', NULL, 0, '2019-11-16 12:01:15', 165),
(171, 11, 'Перечислите имена трёх twig функций, которые вызываются в блоке form_row по умолчанию. Без скобок  и аргументов, в любом порядке.', 'form_widget, form_label, form_errors', NULL, 0, '2019-11-16 12:01:14', 166),
(172, 11, 'Введите имя аргумента, который принимают функции twig из предыдущего вопроса.', 'form', NULL, 0, '2019-11-16 12:01:12', 167),
(173, 11, 'Введите имя переменной, доступной в блоке form_row, проанализировав которую можно определить тип поля ввода, который выводится при работе  кода из этого блока.', 'block_prefixes', NULL, 0, '2019-11-16 12:01:11', 168),
(174, 11, 'Какой тип имеет переменная block_prefixes?', 'array', NULL, 0, '2019-11-16 12:01:11', 169),
(175, 11, 'Как присвоить значение "test" переменной x прямо в twig шаблоне? ( {% ... %} )', '{% set x = "test" %}', NULL, 0, '2019-11-16 12:01:10', 178),
(176, 10, 'Введите одной строкой конфигурацию swiftmailer для .env файла, если ваш ящик user_admin@gmail.com, а пароль 123456.', 'MAILER_URL=gmail://user_admin:123456@localhost', NULL, 0, '2019-11-18 15:34:26', 170),
(177, 10, 'Введите одной строкой конфигурацию swiftmailer для .env файла, если ящик отправителя создан через IspManager, логин admin@site.ru, а пароль 123.\nПорт используйте 25 (без шифрования), smtp domain mail.site.ru', 'MAILER_URL=smtp://mail.site.ru:25?auth_mode=login&username=admin@site.ru&password=123', NULL, 0, '2019-11-18 15:37:39', 171),
(178, 10, 'В вашем проекте установлена конфигурация services.defaults.autoconfigure false. Регистрируем сервис в yaml формате. Какой файл будете редактировать? (c/... .yaml)', 'config/services.yaml', NULL, 0, '2019-11-18 15:56:45', 172),
(179, 10, 'В вашем проекте установлена конфигурация services.defaults.autoconfigure false. Регистрируем сервис в yaml формате. Какую секцию в файле config/services.yaml будете править?', 'services', NULL, 0, '2019-11-18 16:02:33', 173),
(180, 10, 'В вашем проекте установлена конфигурация services.defaults.autoconfigure false. Регистрируем класс App\\Twig\\GazelmeExtension как сервис в yaml формате. Введите логичный псевдоним для сервиса, который будет использоваться как имя секции с конфигурацией.', 'app.twig_extension', NULL, 0, '2019-11-20 08:58:57', 174),
(181, 10, 'В вашем проекте установлена конфигурация services.defaults.autoconfigure false. Регистрируем класс App\\Twig\\GazelmeExtension как сервис в yaml формате. Перечислите три атрибута, которые будут в секции app.twig_extension.', 'class, arguments, tags', NULL, 0, '2019-11-20 08:58:58', 175),
(182, 10, 'В вашем проекте установлена конфигурация services.defaults.autoconfigure false. Регистрируем класс App\\Twig\\GazelmeExtension как сервис в yaml формате.Вы хотите, чтобы он принимал как аргумент объект класса \\Symfony\\Component\\DependencyInjection\\ContainerInterface. Введите соответствующее значение для ключа arguments. ([...])', '["@service_container"]', NULL, 0, '2019-11-20 08:58:59', 176),
(183, 10, 'В вашем проекте установлена конфигурация services.defaults.autoconfigure false. Регистрируем класс App\\Twig\\GazelmeExtension как сервис в yaml формате. Введите строку определяющую минимально необходимый тэг.', '- { name: twig.extension }', NULL, 0, '2019-11-20 08:59:01', 177),
(184, 11, 'Введите значение ключа конфигурации form_themes', '- &quot;form/layout.html.twig&quot;', NULL, 0, '2019-11-20 09:09:02', 163),
(185, 11, 'При перегрузке форм FOSUserBundle какие методы кроме getName и buildForm обязательно должны быть?', 'getParent, getBlockPrefix', NULL, 0, '2019-11-22 09:00:50', 179),
(186, 11, 'При перегрузке форм FOSUserBundle должен ли класс формы наследоваться от класса формы из пакета FOS? (Ответ Да/Нет)', 'Нет', NULL, 0, '2019-11-22 09:25:03', 180);

--
-- Индексы сохранённых таблиц
--

--
-- Индексы таблицы `comments`
--
ALTER TABLE `comments`
  ADD PRIMARY KEY (`id`);

--
-- Индексы таблицы `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`);

--
-- Индексы таблицы `u_tests`
--
ALTER TABLE `u_tests`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `idx_d_name` (`display_name`),
  ADD UNIQUE KEY `idx_ruri` (`reading_uri`);

--
-- Индексы таблицы `u_tests_content`
--
ALTER TABLE `u_tests_content`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT для сохранённых таблиц
--

--
-- AUTO_INCREMENT для таблицы `comments`
--
ALTER TABLE `comments`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT COMMENT 'Первичный ключ.';
--
-- AUTO_INCREMENT для таблицы `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT COMMENT 'Первичный ключ.', AUTO_INCREMENT=4;
--
-- AUTO_INCREMENT для таблицы `u_tests`
--
ALTER TABLE `u_tests`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT COMMENT 'Первичный ключ.', AUTO_INCREMENT=12;
--
-- AUTO_INCREMENT для таблицы `u_tests_content`
--
ALTER TABLE `u_tests_content`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT COMMENT 'Первичный ключ.', AUTO_INCREMENT=187;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
