-- phpMyAdmin SQL Dump
-- version 4.0.8
-- http://www.phpmyadmin.net
--
-- Хост: localhost
-- Время создания: Июн 19 2015 г., 11:56
-- Версия сервера: 5.6.16
-- Версия PHP: 5.5.9

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- База данных: `qtest`
--

-- --------------------------------------------------------

--
-- Структура таблицы `comments`
--

CREATE TABLE IF NOT EXISTS `comments` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT 'Первичный ключ.',
  `part` varchar(128) DEFAULT NULL COMMENT 'Часть url определяющая тип, например quick_start/branching',
  `uid` int(11) DEFAULT NULL COMMENT 'Номер автора',
  `parent_id` int(11) DEFAULT '0' COMMENT 'Номер родительского комментария',
  `title` varchar(128) DEFAULT NULL COMMENT 'Заголовок',
  `body` text COMMENT 'Текст комментария',
  `date_modify` datetime DEFAULT NULL COMMENT 'Время изменения',
  `is_deleted` int(11) DEFAULT '0' COMMENT 'Удален или нет.',
  `date_create` datetime DEFAULT NULL COMMENT 'время создания',
  `is_accept` int(11) DEFAULT '0' COMMENT 'Комментарий прошел модерацию',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Структура таблицы `users`
--

CREATE TABLE IF NOT EXISTS `users` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT 'Первичный ключ.',
  `pwd` varchar(32) DEFAULT NULL COMMENT 'пароль',
  `email` varchar(64) DEFAULT NULL COMMENT 'email',
  `guest_id` varchar(32) DEFAULT NULL COMMENT 'md5( ip datetime) анонимного пользователя загрузившего файл',
  `last_access_time` datetime DEFAULT NULL COMMENT 'время последнего обращения к файлу',
  `is_deleted` int(11) DEFAULT '0' COMMENT 'Удален или нет. Может называться по другому, но тогда в cdbfrselectmodel надо указать, как именно',
  `date_create` datetime DEFAULT NULL COMMENT 'время создания',
  `delta` int(11) DEFAULT NULL COMMENT 'Позиция.  Может называться по другому, но тогда в cdbfrselectmodel надо указать, как именно',
  `name` varchar(64) DEFAULT NULL COMMENT 'Имя пользователя',
  `surname` varchar(64) DEFAULT NULL COMMENT 'Фамилия пользователя',
  `role` int(11) DEFAULT '0' COMMENT 'Роль пользователя 0 - пользователь 1 - модератор - 2 - админ',
  `current_task` varchar(7) DEFAULT NULL COMMENT 'Выбранная в данный момент задача формат: Вариант:Задание',
  `recovery_hash` varchar(32) DEFAULT NULL COMMENT 'Хэш md5 для восстановления пароля',
  `recovery_hash_created` datetime DEFAULT NULL COMMENT 'Время которое хеш действителен',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=4 ;

--
-- Дамп данных таблицы `users`
--

INSERT INTO `users` (`id`, `pwd`, `email`, `guest_id`, `last_access_time`, `is_deleted`, `date_create`, `delta`, `name`, `surname`, `role`, `current_task`, `recovery_hash`, `recovery_hash_created`) VALUES
(1, NULL, NULL, 'd3fad46b24979d15fe635083cd324852', NULL, 0, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL),
(3, '07b68be905ddc7243d684007163d9fcd', 'lamzin80@mail.ru', '493a5bfc47402a69b431c450df7651a9', NULL, 0, NULL, NULL, 'andrey', 'alamzin', 0, NULL, NULL, NULL);

-- --------------------------------------------------------

--
-- Структура таблицы `u_tests`
--

CREATE TABLE IF NOT EXISTS `u_tests` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT 'Первичный ключ.',
  `uid` int(11) DEFAULT NULL COMMENT 'Номер пользователя, загрузившего файл',
  `t_type` int(11) DEFAULT NULL COMMENT 'Тип теста - 0 - варианты ответа, 1 - ответ на вопрос текстовый',
  `display_name` varchar(128) DEFAULT NULL COMMENT 'Имя теста для отображения',
  `short_desc` text COMMENT 'Краткое описание теста',
  `description` text COMMENT 'Полное описание теста',
  `info` text COMMENT 'Полезная информация о тесте, показывается на каждой странице, например информация о том, что все кавычки в ответах должны быть двойными',
  `t_name` varchar(32) DEFAULT NULL COMMENT 'Техническое имя теста',
  `is_deleted` int(11) DEFAULT '0' COMMENT 'Удален или нет.',
  `is_accepted` int(11) DEFAULT '0' COMMENT 'Модерирован или нет.',
  `is_published` int(11) DEFAULT '0' COMMENT 'Опубликован или нет.',
  `date_create` datetime DEFAULT NULL COMMENT 'время создания',
  `delta` int(11) DEFAULT NULL COMMENT 'Позиция. ',
  `folder` varchar(7) DEFAULT NULL COMMENT 'Каталог файлов от files',
  `reading_uri` varchar(255) DEFAULT NULL COMMENT 'Часть url которая транслитируется из display_name',
  `options` text COMMENT 'JSON Прочие опции теста, не вошедшие в структуру таблицы',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_d_name` (`display_name`),
  UNIQUE KEY `idx_ruri` (`reading_uri`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=10 ;

--
-- Дамп данных таблицы `u_tests`
--

INSERT INTO `u_tests` (`id`, `uid`, `t_type`, `display_name`, `short_desc`, `description`, `info`, `t_name`, `is_deleted`, `is_accepted`, `is_published`, `date_create`, `delta`, `folder`, `reading_uri`, `options`) VALUES
(1, 3, 1, 'Тест по Symfony 2', 'Тест по симфони 2, родился по мере чтения сайта symfony-gu.ru.\r\n\r\nВ ответах на вопросы используйте всегда двойные кавычки. Ответы на некоторые вопросы могут показаться вам неудачными, или даже неверными - вы можете предложить свои варианты ответов к тесту на странице комментариев к тесту.', 'Тест по симфони 2, родился по мере чтения сайта symfony-gu.ru', 'В ответах на вопросы используйте всегда двойные кавычки. Ответы на некоторые вопросы могут показаться вам неудачными, или даже неверными - вы можете предложить свои варианты ответов к тесту на странице комментариев к тесту.', 'symfony_2', 0, 1, 1, '2015-05-21 00:00:00', 1, '2015/05', 'test_po_symfony_2', NULL),
(2, 3, 1, 'Тест по Symfony 2 - use base', 'Тест по симфони 2, родился по мере чтения сайта symfony-gu.ru.\r\n\r\nВ ответах на вопросы используйте всегда двойные кавычки. Ответы на некоторые вопросы могут показаться вам неудачными, или даже неверными - вы можете предложить свои варианты ответов к тесту на странице комментариев к тесту.\r\nЭто тупо проверка загрузки вопросов с базы', 'Тест по симфони 2, родился по мере чтения сайта symfony-gu.ru', 'В ответах на вопросы используйте всегда двойные кавычки. Ответы на некоторые вопросы могут показаться вам неудачными, или даже неверными - вы можете предложить свои варианты ответов к тесту на странице комментариев к тесту.', 'ex_base', 0, 1, 1, '2015-05-21 00:00:00', 3, '2015/05', 'ex_base_url', '{"t_compare":"1","time_decision":"60","time_show_error_message":"7","time_show_success_message":"1","time_show_game_over_message":"7","time_show_win_screen":"5","test_score":"5","test_lives":"2","is_skip":"1","test_skip_score":"1","test_skip_border":"15","one_answer_success_message":"\\u041f\\u0440\\u0430\\u0432\\u0438\\u043b\\u044c\\u043d\\u043e!","one_answer_fail_message":"\\u041e\\u0448\\u0438\\u0431\\u043a\\u0430!","gameover_message":"GAME OVER"}'),
(8, 3, 1, 'Реальный тест про фейсбук АПИ', 'Тест по реализации https://www.youtube.com/watch?v=C55Ofl0lsBs', 'Учи ФАПИ', 'Не будет', 'realnii_test_pro_feisbuk_api', 0, 0, 0, '2015-06-08 15:05:36', 6, '2015/06', 'realnii_test_pro_feisbuk_api', '{"t_compare":"1","time_decision":"60","time_show_error_message":"5","time_show_success_message":"1","time_show_game_over_message":"5","time_show_win_screen":"15","test_score":"5","test_lives":"2","is_skip":"1","test_skip_score":"1","test_skip_border":"15","show_answer":"1","one_answer_success_message":"\\u041f\\u0440\\u0430\\u0432\\u0438\\u043b\\u044c\\u043d\\u043e!","one_answer_fail_message":"\\u041e\\u0448\\u0438\\u0431\\u043a\\u0430!","gameover_message":"GAME OVER"}'),
(9, 3, 1, 'Тест по паттернам проектирования', 'По книге &quot;банды четырех&quot;.\r\nСодержит вопросы, перечисляющие классы, реализующие паттерн, методы и поля классов.\r\n', 'По книге &amp;quot;банды четырех&amp;quot;.\r\nСодержит вопросы, перечисляющие классы,реализующие паттерн, методы и поля классов.', 'Правильные ответы на вопросы  стараются соответствовать диаграммам паттернов из книги &quot;Приемы объектно-ориентированного проектирования. Паттерны проектирования&quot;. Но при этом в методах указываются только типы аргументов (Например, на диаграмме классов паттерна Наблюдатель без использования ChangeManager сигнатура метода attach выглядит как Attach(Observer), а с использованием ChangeManager уже как Attach(Observer o). В ответах используйте без аргумента, то есть Attach(Observer). )', 'test_po_patternam_proektirovaniy', 0, 0, 0, '2015-06-18 15:31:19', 7, '2015/06', 'test_po_patternam_proektirovaniya', '{"t_compare":"1","time_decision":"60","time_show_error_message":"7","time_show_success_message":"1","time_show_game_over_message":"7","time_show_win_screen":"15","test_score":"10","test_lives":"2","is_skip":"1","test_skip_score":"1","test_skip_border":"15","show_answer":"1","one_answer_success_message":"\\u041f\\u0440\\u0430\\u0432\\u0438\\u043b\\u044c\\u043d\\u043e!","one_answer_fail_message":"\\u041e\\u0448\\u0438\\u0431\\u043a\\u0430!","gameover_message":"GAME OVER"}');

-- --------------------------------------------------------

--
-- Структура таблицы `u_tests_content`
--

CREATE TABLE IF NOT EXISTS `u_tests_content` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT 'Первичный ключ.',
  `u_tests_id` int(11) DEFAULT NULL COMMENT 'Номер теста',
  `question` text COMMENT 'Текст вопроса',
  `answer` text COMMENT 'Ответ на вопрос, в json формате если u_tests.t_type == 0',
  `r_answer` int(11) DEFAULT NULL COMMENT 'Номер правильного варианта ответа на вопрос если u_tests.t_type == 0',
  `is_deleted` int(11) DEFAULT '0' COMMENT 'Удален или нет.',
  `date_create` datetime DEFAULT NULL COMMENT 'время создания',
  `delta` int(11) DEFAULT NULL COMMENT 'Позиция. ',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=57 ;

--
-- Дамп данных таблицы `u_tests_content`
--

INSERT INTO `u_tests_content` (`id`, `u_tests_id`, `question`, `answer`, `r_answer`, `is_deleted`, `date_create`, `delta`) VALUES
(1, 2, 'Вы находитесь в консоли linux, текущая директория - корневая директория проекта симфони 2.6.6. Введите команду для генерации бандла HelloBundle', 'php app/console generate:bundle --namespace=Acme/HelloBundle', NULL, 0, '2015-06-08 16:05:28', 2),
(2, 2, 'Что такое Acme?', 'Имя компании по умолчанию', NULL, 0, '2015-06-08 16:05:56', 9),
(15, 8, 'Введите адрес страницы на Facebook, которая позволяет авторизовыватсья в веб приложениях. Ответ дайте от корня сайта facebook, например если вы считаете, что это https://facebook.com/api/auth/catch?param1=... введите /api/auth/catch', '/dialog/oauth', NULL, 0, '2015-06-08 16:28:15', 15),
(17, 5, 'Q6', 'A6', NULL, 0, '2015-06-08 15:37:30', 13),
(19, 2, 'Укажите путь к YML файлу конфигурации соединения с базой данных по умолчанию (от корня проекта symfony 2.6.6, например app/config/... или src/Acme/YourBundle/Resources/config/...)', 'app.config/parameters.yml', NULL, 0, '2015-06-08 16:06:23', 14),
(20, 2, 'Вы находитесь в консоли linux, текущая директория - корневая директория проекта симфони 2.6.6 Введите команду для создания базы данных', 'php app/console doctrine:database:create', NULL, 0, '2015-06-08 16:08:12', 22),
(21, 2, 'Вы находитесь в консоли linux, текущая директория - корневая директория проекта симфони 2.6.6 Введите команду для создания класса модели c именем Product в пакете AcmeHelloBundle содержащей три поля: имя, описание и цена. Типы полей: строка в 255 символов, текст, дробное число.', 'php app/console doctrine:generate:entity --entity="AcmeHelloBundle:Product" --fields="name:string(255) description:text price:float"', NULL, 0, '2015-06-08 16:11:28', 11),
(22, 8, 'Перечислите имена трех GET параметров, котрые вам необходимо передать по адресу https://facebook.com/dialog/oauth', 'client_id, response_type, redirect_uri', NULL, 0, '2015-06-08 16:30:20', 16),
(23, 8, 'Введите имя секции в файле composer и строку подключающую facebook php sdk четвертой версии. Вместо точной версии используйте 4.x.x.', '&quot;facebook/php-sdk-v4&quot; : &quot;4.x.x&quot;', NULL, 0, '2015-06-14 16:57:46', 18),
(24, 8, 'Для установки facebook sdk использовать composer install или composer update? (Ответ одним словом)', 'update', NULL, 0, '2015-06-08 16:41:36', 20),
(25, 8, 'Напишите две инструкции use для подключения модулей Facebook sdk необходимых для получения списка друзей TestUsers.', 'use Facebook\\FacebookRequest;\nuse Facebook\\FacebookSession;', NULL, 0, '2015-06-09 11:42:23', 19),
(26, 8, 'Вам доступны идентификатор приложения $app_id  и его &quot;секрет&quot; $app_secret. Введите строку php кода, указывающую FacebookSDK использовать это определенное приложение.', 'FacebookSession::setDefaultApplication($app_id, $app_secret);', NULL, 0, '2015-06-09 14:26:19', 21),
(27, 8, 'Как открыть сессию Facebook в приложении, если у вас есть $access_token авторизованного пользователя? ($session = )', '$session = new FacebookSession($access_token);', NULL, 0, '2015-06-09 12:33:42', 25),
(28, 8, 'Введите url позволяющий получить access_token приложения. Без get параметров.', 'https://graph.facebook.com/oauth/access_token', NULL, 0, '2015-06-08 16:53:08', 22),
(29, 8, 'Перечислите get параметры url, позволяющие получить access_token приложения.', 'client_id, client_secret, grant_type, redirect_uri', NULL, 0, '2015-06-08 16:55:41', 23),
(30, 8, 'Введите значение параметра response_type', 'token', NULL, 0, '2015-06-09 11:54:18', 17),
(31, 8, 'Введите значение параметра grant_type', 'client_credentials', NULL, 0, '2015-06-09 11:56:41', 24),
(32, 8, 'Вам доступен $app_access_token приложения, $access_token авторизованного пользователя facebook, $app_id приложения и $app_secret.\nВведите значение третьего аргумента конструктора FacebookRequest для получения списка TestUsers. Ответ - строка php кода. (&quot;*&quot; . *** . &quot;...&quot; . **;)', '&quot;/&quot; . $app_id . &quot;/accounts/test-users?&quot; . $app_access_token;', NULL, 0, '2015-06-14 16:57:18', 26),
(33, 8, 'Вам доступны переменные $fb_session = new FacebookSession($access_token);\n$path = &quot;/&quot; . $app_id . &quot;/accounts/test-users?&quot; . $app_access_token;\nВведите строку php кода, создающую экземпляр класса FacebookRequest; ($request = ...;)', '$request = new FacebookRequest($fb_session, &amp;quot;GET&amp;quot;, $path);', NULL, 0, '2015-06-09 12:47:40', 27),
(34, 8, 'Вам доступна переменная $request = new FacebookRequest($fb_session, &quot;GET&quot;, $path);\nВведите строку php кода, возвращающую в переменную $data данные результата запроса как массив. ($data = ...&amp;quot;)', '$data = $request-&gt;execute()-&gt;getGraphObject()-&gt;asArray();', NULL, 0, '2015-06-09 12:50:55', 28),
(35, 8, 'Вы выполнили запрос с целью получить список id TestUsers приложения. \n$data = $request-&gt;execute()-&gt;getGraphObject()-&gt;asArray(); Введите наименование ключа массива $data  и его тип, содержащий массив TestUsers (key, type);', 'data, array', NULL, 0, '2015-06-09 12:54:21', 29),
(36, 8, '$test_user = $data[&amp;quot;data&amp;quot;][0];\n\nКак получить access_token тестового пользователя, при условии, что он задан. ($test_user_access_token = $test_user....;)', '$test_user_access_token = $test_user-&gt;access_token;', NULL, 0, '2015-06-09 12:57:33', 30),
(37, 8, '$data = $request-&gt;execute()-&gt;getGraphObject()-&gt;asArray();\n$test_user = $data[&amp;quot;data&amp;quot;][0];\nМожно ли ожидать, что $test_user гарантированно содержит поле access_token?', 'Нет', NULL, 0, '2015-06-09 12:59:49', 31),
(38, 8, '$test_user_access_token = $test_user-&gt;access_token;\n\nВведите значение параметра аргумента $path для конструктора FacebookRequest ($path = &amp;quot;*&amp;quot; . * . **;)', '$path = &amp;quot;/&amp;quot; . $test_user-&gt;id . &amp;quot;/?access_token=&amp;quot; . $test_user_access_token;', NULL, 0, '2015-06-09 13:04:05', 32),
(39, 9, 'Перечислите классы, реализующие паттерн Стратегия.', 'Context, Strategy, ConcreteStrategyN', NULL, 0, '2015-06-18 15:37:45', 33),
(40, 9, 'Паттерн Стратегия. Перечислите методы класса Context. Использование круглых скобок - обязательно.', 'ContextInterface()', NULL, 0, '2015-06-18 15:35:10', 34),
(41, 9, 'Паттерн Стратегия. Перечислите методы класса Strategy. Использование круглых скобок - обязательно.', 'AlgorithmInterface()', NULL, 0, '2015-06-18 15:36:38', 35),
(42, 9, 'В книге &quot;Банды четырех&quot; в описании известных применений паттерна Стратегия есть один пример, очень актуальный для веб-разработки. Введите имя класса, который обычно реализует в веб-движках описываемую в разделе задачу.', 'Validator', NULL, 0, '2015-06-19 12:23:51', 36),
(43, 9, 'Перечислите классы, реализующие паттерн Наблюдатель без использования ChangeManager.', 'Subject, Observer, ConcreteSubject, ConcreteObserver', NULL, 0, '2015-06-19 11:52:39', 37),
(44, 9, 'Паттерн Observer. Перечислите методы класса Subject. Использование круглых скобок - обязательно.', 'attach(Observer), detach(Observer), notify()', NULL, 0, '2015-06-19 12:54:13', 38),
(45, 9, 'Паттерн Observer. Перечислите поля и методы класса ConcreteSubject. Использование круглых скобок для методов - обязательно.', 'getState(), setState(), subjectState', NULL, 0, '2015-06-19 11:57:47', 39),
(46, 9, 'Паттерн Observer. Пусть класс Subject содержит массив _observers \n и длину этого массива в поле _count\nдобавленных с помощью attach() наблюдателей. Наберите необходимую часть кода метода notify(); (На диаграмме этого кода нет, но есть соответствующая выноска)', 'for (int i = 0; i &lt; _count; i++) {\n    _observers[i]-&gt;update();\n}', NULL, 0, '2015-06-19 12:56:28', 40),
(47, 9, 'Паттерн Observer.\nМожет ли конструктор класса Observer принимать аргументом ConcreteSubject?(Да / Нет / Обязан)', 'Обязан', NULL, 0, '2015-06-19 12:10:26', 41),
(48, 9, 'Паттерн Observer.\nКаким образом экхемпляр класса ConcreteObserver получает данные о состоянии субъекта при вызове метода Update? (Через аргументы update / строка кода)', 'subject-&gt;getState();', NULL, 0, '2015-06-19 12:14:36', 42),
(49, 9, 'Паттерн Наблюдатель. Перечислите методы класса Observer. Использование круглых скобок - обязательно.', 'update()', NULL, 1, '2015-06-19 12:16:44', 43),
(50, 9, 'Паттерн Наблюдатель. Перечислите методы класса Observer. Использование круглых скобок - обязательно.', 'update()', NULL, 0, '2015-06-19 12:17:55', 44),
(51, 9, 'Перечислите классы, реализующие паттерн Наблюдатель с использованием ChangeManager (имеется ввиду диаграмма классов из книги).', 'Subject, Observer, ChangeManager, SimpleChangeManager, DAGChangeManager', NULL, 0, '2015-06-19 12:26:54', 45),
(52, 9, 'Паттерн Observer. Перечислите поля и методы класса ChangeManager. Использование круглых скобок для методов - обязательно.', 'Register(Subject, Observer), Unregister()\nUnregister(Subject, Observer)\nNotify(), Subject - Observer mapping', NULL, 0, '2015-06-19 12:32:24', 46),
(53, 9, 'Паттерн Observer. С использованием ChangeManager. Диаграмма. Выноска из какого-то метода выглядит так: chman-&gt;register(this, o);\nВведите имя класса и имя метода.(ClassName::methodName([argument1Type, argument2Type, ...]);)', 'Subject::Attach(Observer);', NULL, 0, '2015-06-19 12:44:18', 47),
(54, 9, 'Паттерн Observer. С использованием ChangeManager. Диаграмма. Выноска из какого-то метода выглядит так: chman-&gt;notify();\nВведите имя класса и имя метода.(ClassName::methodName([argument1Type, argument2Type, ...]);)', 'Subject::Notify();', NULL, 0, '2015-06-19 12:45:15', 48),
(55, 9, 'Паттерн Observer. С использованием ChangeManager. Диаграмма. Процитируйте выноску из метода SimpleChangeManager::notify();', 'Для всех субъектов s\n Для всех наблюдателей o в s\n   o-&gt;Update(s)', NULL, 0, '2015-06-19 12:47:24', 49),
(56, 9, 'Паттерн Observer. С использованием ChangeManager. Диаграмма. Процитируйте выноску из метода DAGChangeManager::notify();', 'Пометить всех наблюдателей для обновления\nОбновить всех помеченных наблюдателей', NULL, 0, '2015-06-19 12:48:25', 50);

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
